App({
  onLaunch: function () {
    console.log("app onLaunch")
  },
  onShow: function () {
    console.log("app onShow")
  },
  onHide: function () {
    console.log("app onHide")
  },
  onError: function (msg) {
  }
})