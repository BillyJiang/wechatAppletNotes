var app = getApp()
Page({
  data:{
    username:null,
    password:null,
    errorInfo:null
  },
  onLoad:function(options){
    // 生命周期函数--监听页面加载
  },
  onReady:function(){
    // 生命周期函数--监听页面初次渲染完成
  },
  onShow:function(){
    // 生命周期函数--监听页面显示
  },
  onHide:function(){
    // 生命周期函数--监听页面隐藏
  },
  onUnload:function(){
    // 生命周期函数--监听页面卸载
  },
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
  },
  onReachBottom: function() {
    // 页面上拉触底事件的处理函数
  },
  onShareAppMessage: function() {
    // 用户点击右上角分享
    return {
      title: 'title', // 分享标题
      desc: 'desc', // 分享描述
      path: 'path' // 分享路径
    }
  },
  loginBtnClick:function(){
    if(this.data.username == "admin" && this.data.password == "admin"){
        app.appData.userInfo = {username:this.data.username,password:this.data.password}

        console.log("true")
        wx.switchTab({
          url: '../user/user',
          success: function(res){
            // success
          },
          fail: function() {
            // fail
          },
          complete: function() {
            // complete
          }
        })
    }else{
      this.setData({errorInfo:"用户名或密码不对，请重新输入"})
      console.log("用户名或密码不对，请重新输入")
      // wx.showToast({
      //   title: this.data.errorInfo,
      //   duration: 2000
      // })

      wx.showModal({
        title: '提示',
        content: '用户名或密码不正确，请重新输入',
        showCancel: false,
        success: function(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          }
        }
      })
    }
  },

  usernameInput: function(e){
    // console.log(e.detail.value)
    this.setData({username:e.detail.value})
  },
  passwordInput:function(e){
    // console.log(e.detail.value)
    this.setData({password:e.detail.value})
  }
})